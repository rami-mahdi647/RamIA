export default function Interchain(){return (<div className='space-y-4'><div className='badge'>Interchain Router</div><div>UI para puentes entre BTC/ETH/Polygon/BNB/Cosmos/DAG.</div></div>)}
