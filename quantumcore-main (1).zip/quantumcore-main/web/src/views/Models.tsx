export default function Models(){return (<div className='space-y-4'><div className='badge'>Model Lab</div><div>32 QNNs con métricas y experimentos (conecta scripts/qnn).</div></div>)}
