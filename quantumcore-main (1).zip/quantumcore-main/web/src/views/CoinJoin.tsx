export default function CoinJoin(){return (<div className='space-y-4'><div className='badge'>CoinJoin</div><div>UI de mezcla UTXO (requiere coordinador externo).</div></div>)}
