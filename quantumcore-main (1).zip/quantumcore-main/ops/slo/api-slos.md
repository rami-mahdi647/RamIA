# SLOs iniciales
- Disponibilidad API >= 99.9%
- Error rate < 1%
- Latencia p95 < 400 ms

**Alertas sugeridas**
- 5xx > 2% por 5 min
- p95 > 400 ms por 10 min
- userOps/tx fallidas > umbral/min
