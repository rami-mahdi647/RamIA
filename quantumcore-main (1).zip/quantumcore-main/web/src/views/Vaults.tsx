export default function Vaults(){return (<div className='space-y-4'><div className='badge'>Vaults & Minería</div><div>Panel con dificultad, mempool, últimos bloques (ver Dashboard).</div></div>)}
