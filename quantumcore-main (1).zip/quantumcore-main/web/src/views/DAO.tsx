export default function DAO(){return (<div className='space-y-4'><div className='badge'>DAO</div><div>Conecta tus endpoints en backend/dao o scripts/dao.</div></div>)}
