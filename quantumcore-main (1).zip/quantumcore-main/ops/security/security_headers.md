# Cabeceras de Seguridad recomendadas
- Strict-Transport-Security
- Content-Security-Policy (sin 'unsafe-inline' si es posible)
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY
- Referrer-Policy: no-referrer
- Permissions-Policy: geolocation=(), microphone=()
