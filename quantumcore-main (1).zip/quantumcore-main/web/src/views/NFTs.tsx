export default function NFTs(){return (<div className='space-y-4'><div className='badge'>NFTs</div><div>Quantum Badges conectados a tu backend/contratos.</div></div>)}
