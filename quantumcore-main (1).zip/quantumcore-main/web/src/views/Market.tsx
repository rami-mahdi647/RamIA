export default function Market(){return (<div className='space-y-4'><div className='badge'>Market Sentinel</div><div>Tendencias, PRs, costes, tickets (conecta fuentes).</div></div>)}
