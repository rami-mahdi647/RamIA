export default function Settings(){return (<div className='space-y-4'><div className='badge'>Settings</div><div>Configura direcciones, RPCs y preferencias.</div></div>)}
